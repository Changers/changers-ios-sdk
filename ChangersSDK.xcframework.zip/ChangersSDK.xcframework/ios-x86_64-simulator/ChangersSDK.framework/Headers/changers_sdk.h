//
//  changers_sdk.h
//  changers-sdk
//
//  Created by Clement Yerochewski on 19/05/2020.
//  Copyright © 2020 Blacksquared Gmbh. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for changers_sdk.
FOUNDATION_EXPORT double changers_sdkVersionNumber;

//! Project version string for changers_sdk.
FOUNDATION_EXPORT const unsigned char changers_sdkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <changers_sdk/PublicHeader.h>


